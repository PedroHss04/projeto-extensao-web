create schema vinhos_da_bia

use vinhos_da_bia

CREATE TABLE vinhos (
    id INT AUTO_INCREMENT PRIMARY KEY, -- ID único para cada vinho
    nome VARCHAR(255) NOT NULL,       -- Nome do vinho
    imagem VARCHAR(255),              -- Caminho ou URL da imagem
    preco DECIMAL(10, 2) NOT NULL,    -- Preço com duas casas decimais
    descricao TEXT,                   -- Descrição detalhada do vinho
    codigo_referencial VARCHAR(50) NOT NULL UNIQUE, -- Código único do vinho
    tipo VARCHAR(50),                 -- Tipo (ex. tinto, branco, rosé)
    pais VARCHAR(100),                -- País de origem
    ativo BOOLEAN DEFAULT TRUE        -- Indicador se o vinho está ativo
)