<?php
// Credenciais fornecidas pelo InfinityFree
$dbHost = 'sql210.infinityfree.com';  // Endereço do servidor MySQL
$dbUsername = 'if0_37766093';        // Nome de usuário do banco de dados
$dbpassword = 'k6cycvV6XP5v8g';      // Senha do banco de dados
$dbName = 'if0_37766093_vinhos_da_bia';  // Nome do banco de dados

// Criar a conexão
$conexao = new mysqli($dbHost, $dbUsername, $dbpassword, $dbName);

// Verificar se há erro na conexão
if ($conexao->connect_error) {
    die("Erro na conexão: " . $conexao->connect_error);
}

?>
