<?php include "./connect.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM vinhos WHERE id = ?";
    $stmt = $conexao->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            header("Location: cadastro.php");
        } else {
            echo "Erro ao apagar a despesa.";
        }
        $stmt->close();
    } else {
        echo "Erro ao preparar a consulta.";
    }
}
$conexao->close();
?>