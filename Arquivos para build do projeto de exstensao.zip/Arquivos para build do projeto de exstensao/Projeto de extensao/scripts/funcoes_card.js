document.addEventListener("DOMContentLoaded", () => {
  // Seleciona todos os botões de "Adicionar ao Carrinho"
  const botoesAdicionarCarrinho = document.querySelectorAll(
    ".adicionar-carrinho"
  );

  botoesAdicionarCarrinho.forEach((botao) => {
    botao.addEventListener("click", (event) => {
      // Obtém os dados do produto apenas do botão clicado
      const produto = JSON.parse(event.target.dataset.produto);

      // Adiciona somente o produto clicado à Session Storage
      adicionarProdutoNaSessionStorage(produto);

      // Atualiza o contador de itens do carrinho
      atualizarQuantidadeCarrinho();
    });
  });

  // Atualiza o contador ao carregar a página
  atualizarQuantidadeCarrinho();
});

// Função para adicionar produto na Session Storage
function adicionarProdutoNaSessionStorage(produto) {
  // Recupera o carrinho atual da Session Storage (se existir)
  let carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];

  // Verifica se o produto já está no carrinho (opcional)
  const produtoExiste = carrinho.some(
    (item) => item.codigo_referencial === produto.codigo_referencial
  );
  if (produtoExiste) {
    console.log("Produto já está no carrinho:", produto);
    return; // Não adiciona duplicatas
  }

  // Adiciona o novo produto ao carrinho
  carrinho.push(produto);

  // Atualiza a Session Storage com o carrinho atualizado
  sessionStorage.setItem("carrinho", JSON.stringify(carrinho));

  console.log("Produto adicionado ao carrinho:", produto);
  console.log("Carrinho atualizado:", carrinho);
}

// Função para atualizar o contador de itens do carrinho
function atualizarQuantidadeCarrinho() {
  const carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];
  const carrinhoCount = document.getElementById("carrinhoCount");
  carrinhoCount.textContent = carrinho.length;
}
