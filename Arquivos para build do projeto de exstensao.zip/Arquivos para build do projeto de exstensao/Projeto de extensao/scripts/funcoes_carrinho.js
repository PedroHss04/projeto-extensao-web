// Seleciona elementos
let carrinhoBtn = document.getElementById("carrinhoBtn");
let carrinhoSidebar = document.getElementById("carrinhoSidebar");
let carrinhoItens = document.getElementById("carrinhoItens");
let finalizarBtn = document.getElementById("finalizarBtn");
let overlay = document.getElementById("overlay");
let nomeCliente = document.getElementById("nomeCliente");
let carrinhoCount = document.getElementById("carrinhoCount");

// Alterna exibição do carrinho
carrinhoBtn.addEventListener("click", () => {
  carrinhoSidebar.classList.add("open");
  overlay.style.display = "block";
  exibirCarrinho();
});

// Fecha o carrinho ao clicar no overlay
overlay.addEventListener("click", fecharCarrinho);

// Função para fechar o carrinho
function fecharCarrinho() {
  carrinhoSidebar.classList.remove("open");
  overlay.style.display = "none";
}

// Atualiza a quantidade de itens no botão do carrinho
function atualizarQuantidadeCarrinho() {
  const carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];
  carrinhoCount.textContent = carrinho.length;
}

carrinhoBtn.addEventListener("click", () => {
  carrinhoSidebar.classList.add("open");
  overlay.style.display = "block";
  exibirCarrinho();
  atualizarQuantidadeCarrinho();
});

// Função para exibir itens do carrinho
function exibirCarrinho() {
  carrinhoItens.innerHTML = ""; // Limpa carrinho antes de renderizar
  const carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];

  if (carrinho.length === 0) {
    carrinhoItens.innerHTML = "<p>Seu carrinho está vazio.</p>";
  } else {
    carrinho.forEach((item, index) => {
      const itemDiv = document.createElement("div");
      itemDiv.classList.add("carrinho-item");

      itemDiv.innerHTML = `
            <span>${item.nome} - R$${parseFloat(item.preco).toFixed(2)}</span>

            <button class="remover-item" data-index="${index}">Remover</button>
          `;

      carrinhoItens.appendChild(itemDiv);
    });

    // Adiciona evento de remoção para cada botão
    document.querySelectorAll(".remover-item").forEach((btn) => {
      btn.addEventListener("click", (event) => {
        const index = event.target.dataset.index;
        removerItemCarrinho(index);
      });
    });
  }
}

// Função para remover item do carrinho
function removerItemCarrinho(index) {
  let carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];
  carrinho.splice(index, 1); // Remove o item pelo índice
  sessionStorage.setItem("carrinho", JSON.stringify(carrinho));
  exibirCarrinho(); // Atualiza a exibição do carrinho
  atualizarQuantidadeCarrinho(); // Atualiza o contador
}

// Ação ao finalizar
finalizarBtn.addEventListener("click", () => {
  const carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];
  const nome = nomeCliente.value.trim();

  if (carrinho.length === 0) {
    alert("Seu carrinho está vazio.");
    return;
  }

  if (!nome) {
    alert("Por favor, insira seu nome.");
    return;
  }

  // Monta a mensagem do WhatsApp
  let mensagem = `*Pedido de ${nome}*\n\n📦 *Detalhes do pedido:*\n`;
  let total = 0;

  carrinho.forEach((item) => {
    mensagem += `- ${item.nome}: R$${parseFloat(item.preco).toFixed(2)}\n`;
    total += parseFloat(item.preco);
  });

  mensagem += `\n💵 *Total a pagar:* R$${parseFloat(total).toFixed(
    2
  )}\n\nObrigado pelo seu pedido!`;

  // Redireciona para o WhatsApp
  const telefone = "554799475275"; // Substitua pelo número do WhatsApp
  const url = `https://wa.me/${telefone}?text=${encodeURIComponent(mensagem)}`;
  window.location.href = url;
  atualizarQuantidadeCarrinho();
});



window.addEventListener("load", atualizarQuantidadeCarrinho);
