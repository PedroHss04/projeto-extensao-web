<?php 
include "./connect.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM vinhos WHERE id = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $produto = $result->fetch_assoc();
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $preco = $_POST['preco'];
    $codigo_referencial = $_POST['codigo_referencial'];
    $tipo = $_POST['tipo'];
    $descricao = $_POST['descricao'];
    $localidade = $_POST['localidade'];

    // Manipulação da imagem
    $imagem_atual = $_POST['imagem_atual'];
    $nova_imagem = $_FILES['imagem']['name'];
    $imagem_tmp = $_FILES['imagem']['tmp_name'];
    $nome_unico = uniqid('img_', true) . '.' . $extensao;
    $imagem_pasta = "images/" . $nome_unico;

    // Verifica se há uma nova imagem e faz o upload
    if (!empty($nova_imagem)) {
        if (move_uploaded_file($imagem_tmp, $imagem_pasta)) {
            $imagem_final = $imagem_pasta;  // Nova imagem
        } else {
            echo "<script>exibirAlerta('error', 'Erro ao enviar a imagem.');</script>";
            $imagem_final = $imagem_atual;  // Caso falhe, mantemos a imagem atual
        }
    } else {
        // Se não houver nova imagem, mantemos a imagem atual
        $imagem_final = $imagem_atual;
    }

    // Atualiza o produto no banco de dados
    $sql = "UPDATE vinhos SET nome = ?, preco = ?, codigo_referencial = ?, tipo = ?, pais = ?, imagem = ?, descricao = ? WHERE id = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("sdsssssi", $nome, $preco, $codigo_referencial, $tipo, $localidade, $imagem_final, $descricao, $id);
    
    if ($stmt->execute()) {
        echo "<script>window.location.href = 'index.php';</script>"; // Redireciona após sucesso
    } else {
        echo "<script>exibirAlerta('error', 'Erro ao atualizar o produto: " . $stmt->error . "');</script>";
    }
    $stmt->close();
}
$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Editar Produto</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="./styles/styles.css">
  <link rel="stylesheet" href="./styles/styles_cadastro.css">
</head>

<body>
  <div class="container">
    <h2>Editar Produto</h2>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="id" value="<?= $produto['id'] ?>">
      <input type="hidden" name="imagem_atual" value="<?= $produto['imagem'] ?>">

      <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" class="form-control" id="nome" name="nome" value="<?= htmlspecialchars($produto['nome']) ?>" required>
      </div>

      <div class="form-group">
        <label for="descricao">Descrição</label>
        <input type="text" class="form-control" id="descricao" name="descricao" value="<?= htmlspecialchars($produto['descricao']) ?>" required>
      </div>

      <div class="form-group">
        <label for="imagem">Imagem</label>
        <div>
          <!-- Aqui exibimos a imagem atual -->
          <img src="<?= $produto['imagem'] ?>" alt="Imagem do Produto" style="width: 100px; margin-bottom: 10px;">
        </div>
        <input type="file" class="form-control" id="imagem" name="imagem">
      </div>

      <div class="form-group">
        <label for="preco">Preço</label>
        <input type="number" class="form-control" id="preco" name="preco" step="0.01" value="<?= number_format($produto['preco'], 2, '.', '') ?>" required>
      </div>

      <div class="form-group">
        <label for="codigo_referencial">Código Referencial</label>
        <input type="text" class="form-control" id="codigo_referencial" name="codigo_referencial" value="<?= htmlspecialchars($produto['codigo_referencial']) ?>" required>
      </div>

      <div class="form-group">
        <label for="tipo">Tipo</label>
        <select class="form-select" id="tipo" name="tipo" required>
          <option value="Vinho Tinto" <?= $produto['tipo'] == 'Vinho Tinto' ? 'selected' : '' ?>>Vinho Tinto</option>
          <option value="Vinho Branco" <?= $produto['tipo'] == 'Vinho Branco' ? 'selected' : '' ?>>Vinho Branco</option>
          <option value="Espumante" <?= $produto['tipo'] == 'Espumante' ? 'selected' : '' ?>>Espumante</option>
        </select>
      </div>

      <div class="form-group">
        <label for="localidade">Localidade</label>
        <input type="text" class="form-control" id="localidade" name="localidade" value="<?= htmlspecialchars($produto['pais']) ?>" required>
      </div>

      <button type="submit" class="btn btn-primary">Salvar</button>
      <a href="./cadastro.php" class="btn btn-secondary">Cancelar</a>
    </form>
  </div>

  <script>
    function exibirAlerta(tipo, mensagem) {
      var alerta = document.createElement('div');
      alerta.className = 'alerta alerta-' + tipo;
      alerta.innerText = mensagem;

      document.body.appendChild(alerta);
      alerta.style.display = 'block';

      setTimeout(function() {
        alerta.style.display = 'none';
        alerta.remove();
      }, 5000);
    }
  </script>
</body>

</html>
