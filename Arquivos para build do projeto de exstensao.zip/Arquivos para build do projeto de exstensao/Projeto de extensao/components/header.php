<nav class="navbar p-3" style="background-color: var(--cor_primaria)">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center gap-4" href="./index.php">
      <img src="logo.jpg" width="50" class="d-inline-block align-text-top" />
      <span class="fs-3" style="color: var(--cor_secundaria); ">Vinhos da Bia</span>
    </a>

    <div id="registerButtonContainer" class="d-flex align-items-center ms-auto">
      <button id="registerButton" class="btn" style="display: none; background-color: var(--cor_secundaria)" onclick="window.location.href='cadastro.php'">Cadastrar</button>
    </div>
  </div>
</nav>

<script>
  // Verifica se o usuário está logado no localStorage
  if (localStorage.getItem('isLoggedIn') === 'true') {
    // Exibe o botão "Cadastrar" se o usuário estiver logado
    document.getElementById('registerButton').style.display = 'block';
  }
</script> 