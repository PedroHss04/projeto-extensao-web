<div class="card mx-auto" style="width: 18rem; background-color: var(--cor_primaria); box-shadow: -3px 3px 10px 2px rgb(0 0 0 / 40%);">
    <img src="/<?= $linha['imagem'] ?>" class="card-img-top" alt="Imagem do vinho" style="max-width: 100%; max-height: 200px; object-fit: contain;">
    <div class="card-body">
        <h5 class="card-title text-white"><?= htmlspecialchars($linha['nome']) ?></h5>
        <p class="card-text text-white">Tipo: <?= htmlspecialchars($linha['tipo']) ?></p>
        <p class="card-text text-white">País: <?= htmlspecialchars($linha['pais']) ?></p>
        <p class="card-text text-white d-flex justify-content-center align-items-center">R$ <?= htmlspecialchars($linha['preco']) ?></p>
    </div>
    <div class="card-body d-flex justify-content-center align-items-center">
        <button
            class="btn btn-outline-light btn-sm adicionar-carrinho"
            data-produto='<?= json_encode([
                                'codigo_referencial' => $linha['codigo_referencial'],
                                'nome' => $linha['nome'],
                                'tipo' => $linha['tipo'],
                                'pais' => $linha['pais'],
                                'preco' => $linha['preco']
                            ]) ?>'>
            Adicionar ao Carrinho
        </button>
    </div>
</div>
<script src="./scripts/funcoes_card.js"></script>
