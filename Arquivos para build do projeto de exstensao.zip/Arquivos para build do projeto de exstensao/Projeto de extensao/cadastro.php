<?php include "connect.php" ?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet"> <!-- Bootstrap Icons -->

    <!-- Fonte -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@100..900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="./styles/styles.css">

    <link rel="stylesheet" href="./styles/styles_cadastro.css">

</head>

<body>
    <?php include "components/header.php"; ?>
    <div class="container">
        <h2>Cadastro de Produto</h2>
        <form action="cadastro.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="nome">Nome do Produto</label>
                <input type="text" name="nome" id="nome" required maxlength="255">
            </div>
            <div class="form-group">
                <label for="descricao">Descrição</label>
                <input type="text" name="descricao" id="descricao" required maxlength="255">
            </div>
            <div class="form-group">
                <label for="imagem">Imagem do Produto</label>
                <input type="file" name="imagem" id="imagem" required maxlength="255">
            </div>
            <div class="form-group">
                <label for="preco">Preço</label>
                <input type="number" step="1" name="preco" id="preco" required maxlength="10">
            </div>
            <div class="form-group">
                <label for="codigo_referencial">Código Referencial</label>
                <input type="text" name="codigo_referencial" id="codigo_referencial" required maxlength="50">
            </div>
            <div class="form-group">
                <label for="tipo">Tipo</label>
                <select name="tipo" id="tipo" required>
                    <option value="Vinho Tinto">Vinho Tinto</option>
                    <option value="Vinho Branco">Vinho Branco</option>
                    <option value="Espumante">Espumante</option>
                </select>
            </div>
            <div class="form-group">
                <label for="localidade">Localidade</label>
                <input type="text" name="localidade" id="localidade" required maxlength="100">
            </div>
            <div class="form-group">
                <button type="submit">Cadastrar Produto</button>
            </div>
        </form>
    </div>
    <div class="mt-5 p-5">
        <h2>Produtos Cadastrados</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Imagem</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Preço</th>
                    <th>Tipo</th>
                    <th>Localidade</th>
                    <th>Código Referencial</th>
                    <th>Ativo ?</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Consulta para obter produtos cadastrados
                $sql = "SELECT * FROM vinhos";
                $result = $conexao->query($sql);

                if ($result->num_rows > 0) {
                    // Exibir cada produto como uma linha na tabela
                    while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><img src=<?= $row['imagem'] ?> alt='Imagem do produto' style='width: 100px;'></td>
                            <td><?= htmlspecialchars($row['nome']) ?> </td>
                            <td><?= htmlspecialchars($row['descricao']) ?> </td>
                            <td>R$ <?= number_format($row['preco'], 2, ',', '.') ?> </td>
                            <td><?= htmlspecialchars($row['tipo']) ?> </td>
                            <td><?= htmlspecialchars($row['pais']) ?> </td>
                            <td><?= htmlspecialchars($row['codigo_referencial']) ?> </td>
                            <td><?= htmlspecialchars($row['ativo'] == 1 ? 'Sim' : 'Não') ?> </td>
                            <td>
                                <button class="btn btn-outline-danger btn-sm" onclick="deleteExpense(<?= $row['id'] ?>)" title="Excluir">
                                    <i class="bi bi-x-circle"></i> Excluir
                                </button>
                                <button class="btn btn-outline-success btn-sm" onclick="window.open('edit.php?id=<?= $row['id'] ?>')" title="Editar">
                                    <i class="bi bi-pencil"></i> Editar
                                </button>
                            </td>
                        </tr>
                    <?php }
                } else { ?>
                    <tr>
                        <td colspan='6'>Nenhum produto cadastrado ainda.</td>
                    </tr>;
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script>
        function deleteExpense(id) {
            if (confirm('Tem certeza que deseja apagar esta despesa?')) {
                window.location.href = 'delete.php?id=' + id;
            }
        }
    </script>

</body>

</html>


<?php

// Verificar se houve erro na conexão
if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Receber os dados do formulário
    $nome = $_POST['nome'];
    $preco = $_POST['preco'];
    $codigo_referencial = $_POST['codigo_referencial'];
    $tipo = $_POST['tipo'];
    $localidade = $_POST['localidade'];
    $descricao = $_POST['descricao'];

    // Manipulação da imagem
    $imagem_tmp = $_FILES['imagem']['tmp_name'];
    $extensao = pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION); // Obtém a extensão do arquivo
    $nome_unico = uniqid('img_', true) . '.' . $extensao; // Cria um nome único
    $imagem_pasta = "images/" . $nome_unico;

    // Mover a imagem para a pasta de uploads
    if (move_uploaded_file($imagem_tmp, $imagem_pasta)) {
        // Inserir os dados no banco de dados
        $sql = "INSERT INTO vinhos (nome, imagem, preco, codigo_referencial, tipo, pais, descricao, ativo) 
                VALUES ('$nome', '$imagem_pasta', '$preco', '$codigo_referencial', '$tipo', '$localidade', '$descricao', 1)";
        if ($conexao->query($sql) === TRUE) {

            echo "<script>
                    window.onload = function() {
                        exibirAlerta('success', 'Produto cadastrado com sucesso!');
                    }
                  </script>";
        } else {
            echo "<script>
                    window.onload = function() {
                        exibirAlerta('error', 'Erro ao cadastrar o produto: " . $conexao->error . "');
                    }
                  </script>";
        }
    } else {
        echo "<script>
                window.onload = function() {
                    exibirAlerta('error', 'Erro ao enviar a imagem.');
                }
              </script>";
    }
}

$conexao->close();
?>

<script>
    function exibirAlerta(tipo, mensagem) {
        var alerta = document.createElement('div');
        alerta.className = 'alerta alerta-' + tipo;
        alerta.innerText = mensagem;

        document.body.appendChild(alerta);
        alerta.style.display = 'block';

        // Remover alerta após 5 segundos
        setTimeout(function() {
            alerta.style.display = 'none';
            alerta.remove();
        }, 5000);
    }
</script>