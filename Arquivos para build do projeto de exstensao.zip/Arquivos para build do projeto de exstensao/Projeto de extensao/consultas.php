<?php include "connect.php";

$sql = "SELECT * FROM vinhos";
$consulta_produtos = $conexao->query($sql);
